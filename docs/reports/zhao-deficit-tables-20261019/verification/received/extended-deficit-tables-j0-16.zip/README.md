# Extended data tables: Italian domination on labelled cycles

Prepared by Chengye Zhao (College of Sciences, China Jiliang University), as a continuation of
> W. Zhang and H. Ma, *Weight-refined Italian domination on labelled cycles* (two-page note, 9 October 2026)
> and the data repository <https://github.com/the-omega-institute/italian-domination-cycles>.

These files **extend** that repository from deficits j = 0…10 to **j = 0…16**, and are meant to be
merged into it. Everything is recomputed independently with exact integer arithmetic from

    Q = [[0,0,0,0,1],[0,0,0,1,1],[1,0,0,1,1],[0,1,0,1,1],[0,0,1,1,1]],
    Q(x) = diag(1,1,1,x,x^2) Q,        D_I(C_n, x) = tr(Q(x)^n),
    M(y) = diag(y^2,y^2,y^2,y,1) Q,   H(z,y) = det(I - z M(y)),
    G_j(z) = [y^j] S(z,y),  S(z,y) = -z d/dz log H(z,y) = N_j(z) / (1 - z)^{j+1}.

No floating point is used anywhere.

## Files

| File | Content |
|---|---|
| `coefficients_extended.csv` | d_I(C_n, k) for 3 ≤ n ≤ 100 and 0 ≤ k ≤ 2n, long format (n, k, value), zeros included |
| `deficits_extended.csv` | wide format: one row per n, columns c_{n,j} = d_I(C_n, 2n − j) for j = 0…16; an **empty cell** means j > 2n, where d_I(C_n, 2n − j) is not defined |
| `deficit_formulas_extended.json` | N_j coefficients (low degree first), deg N_j, least threshold n_0(j), and the expanded/factored closed form, for j = 0…16 |
| `certificate_extended.json` | SHA256 of the three data files and a record of all checks |

## New results (j = 11 … 16)

| j | deg N_j | least threshold n_0(j) |
|---|---------|------------------------|
| 11 | 17 | 6 |
| 12 | 19 | 7 |
| 13 | 20 | 7 |
| 14 | 23 | 9 |
| 15 | 25 | 10 |
| 16 | 25 | 9 |

In every case n_0(j) = deg N_j − j, exactly as for j ≤ 10, and minimality is verified by evaluating
one step below n_0 (the closed form gives a nonzero value there, whereas d_I(C_n, 2n − j) = 0).

## Checks performed

1. **Against your repository.** All 10,192 cells of `coefficients.json` reproduced exactly; the
   numerators N_j and the thresholds n_0(j) agree with your `deficit_formulas.json` for every
   j = 0…10 (same convention: the formal trace terms of lengths 1 and 2 are retained in S).
2. **Brute force.** Exhaustive enumeration of all 3^n functions for 3 ≤ n ≤ 12 agrees with the
   table coefficient by coefficient (3^12 = 531,441 functions at n = 12).
3. **Threshold minimality.** For each j ≤ 16 the closed form holds for every n ≥ n_0 up to n = 100
   and fails at n = n_0 − 1.
4. **Totals.** a(n) = D_I(C_n, 1) satisfies a(n+5) = 2a(n+4) + 2a(n+3) + a(n+2) − a(n+1) − a(n)
   for 3 ≤ n ≤ 95, with a(3) … a(7) = 23, 60, 167, 467, 1297.

## Note on thresholds

The threshold phenomenon comes from the polynomial extension of B_j(t) = (1/j!) ∏_{h<j}(t − h):
it does not vanish for negative t, where it is combinatorially meaningless. Hence
c_{n,j} = Σ_r a_{j,r} B_j(n − r + j) agrees with the true coefficient as soon as n ≥ deg N_j − j,
and below that the out-of-range terms contribute spurious values.

## Reproducibility

`coefficients_extended.csv` is exactly your `coefficients.json` in long format (same 10,192 cells,
zero differences), so the two can be concatenated or replaced without any conversion of the j ≤ 10 part.
`deficit_formulas_extended.json` uses your convention for N_j and n_0(j), so the j ≤ 10 entries
duplicate yours and only j = 11…16 are new.

`certificate_extended.json` records SHA256 hashes; all files are written with LF line endings so the
hashes are platform independent.
