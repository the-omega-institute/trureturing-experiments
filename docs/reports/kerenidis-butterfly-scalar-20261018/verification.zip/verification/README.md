# Exact butterfly scalar verification

This directory contains the exact arithmetic supporting *Butterfly gradient
variances at half filling and four particles*, Haobo Ma and Wenlin Zhang,
18 October 2026. All mode labels are zero based. The ensemble is one pass of
the increasing-stride butterfly, with independent uniform rotation angles
and phases, the Walsh-spread magic-block input, and the first phase on mode 0.

Run these commands **from this directory** with Python 3. No third-party
packages are required for the main verification commands.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 code/verify_certificate.py
PYTHONDONTWRITEBYTECODE=1 python3 code/check_round1.py
PYTHONDONTWRITEBYTECODE=1 python3 code/check_haar.py
```

The first command regenerates moment exponents, branch transitions and base
integrals from the circuit, then verifies every coefficient identity in the
delivered exponential-polynomial certificate. It checks 18,918 initial-value
and recurrence identity pairs: five k=2 readouts and all six k=4 readouts.
The coefficient arithmetic in the verifier is separate from the solver.
The circuit reduction and the all-depth inequality arguments are in the note.

The second command checks the five-state half-filling transfer for all six
readouts. It regenerates the sixteen wedge-mask transfers and low-layer
terminal vectors, verifies their reduction to the three displayed matrices,
checks the exact annihilator P(M)=0, and verifies five initial conditions.
Together with the proved circuit reduction, these are a finite certificate
of the all-depth half-filling formulas. It also compares 6,603 RDM entries
with the full Walsh exterior transformation, runs 36 separate direct-Fourier
versus moment-recurrence comparisons, and checks the exact table arithmetic
and its half-filling endpoints.

The third command independently constructs the unspread RDM by annihilating
Fock states, checks both Haar commutator norms, and checks the Haar benchmark
for every allowed even particle number at n=4,8,16 (seven cases).

To regenerate the moment certificate:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 code/build_certificate.py
```

To reproduce each direct exact integration table:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 code/fast_scalar.py 16 0 1
PYTHONDONTWRITEBYTECODE=1 python3 code/fast_scalar.py 16 1 3
PYTHONDONTWRITEBYTECODE=1 python3 code/fast_scalar.py 32 0 1
PYTHONDONTWRITEBYTECODE=1 python3 code/fast_scalar.py 32 1 3
PYTHONDONTWRITEBYTECODE=1 python3 code/fast_scalar.py 64 0 1
PYTHONDONTWRITEBYTECODE=1 python3 code/fast_scalar.py 64 1 3
PYTHONDONTWRITEBYTECODE=1 python3 code/fast_scalar.py 128 0 1
PYTHONDONTWRITEBYTECODE=1 python3 code/fast_scalar.py 128 1 3
```

Each command computes every even 2 <= k <= n/2. The n=128 runs took about
two minutes each on the development machine and cache several million path
moments. Results are exact fractions; decimal fields are for display.
`fast_scalar.py` uses a separate first-layer Fourier grouping and full-size
unique-path integrals, not the layer transitions or the coefficient solver.
The auxiliary n=8 table is also included; it is outside the 120-point table
inventory in the note.

The older supplementary scripts `direct_fourier.py`, `check_matrix_bridge.py`
and `check_fixed_k.py` are retained with their dependencies. They are not needed
for the three commands above; this package's fresh verification claims are
those explicitly described above and recorded in the JSON receipts.

These computations are not Lean formalizations. The fixed-k asymptotic does
not prove uniformity in growing k. At half filling the ratio is unbounded
above, and a sparse uniform comparison remains open. No other parameter
location, repeated-pass circuit, or general readout geometry is covered.

The surrounding archive also contains `review-work/`: separate referee
implementations, with Python and SymPy dependencies, and their actual check
receipts. See the archive's top-level README for their invocation and scope.
