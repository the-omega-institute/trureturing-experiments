"""Solve the finite triangular moment recursion as exponential polynomials."""
from pair_recursion import *

def p_add(a,b):
    c=[Q(0)]*max(len(a),len(b))
    for i,x in enumerate(a):c[i]+=x
    for i,x in enumerate(b):c[i]+=x
    while c and not c[-1]:c.pop()
    return tuple(c)
def p_mul(a,b):
    c=[Q(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]+=x*y
    return tuple(c)
def ep_add(a,b,scale=Q(1)):
    c=dict(a)
    for r,p in b.items():
        c[r]=p_add(c.get(r,()),tuple(scale*x for x in p))
        if not c[r]:del c[r]
    return c
def ep_mul(a,b):
    c={}
    for r,p in a.items():
        for s,q in b.items():c=ep_add(c,{r*s:p_mul(p,q)})
    return c

def particular(lam,r,p):
    d=len(p)-1;resonant=(lam==r)
    out=[Q(0)]*(d+1+resonant)
    if resonant:
        for j in range(d,-1,-1):
            out[j+1]=(p[j]-r*sum(comb(k,j)*out[k] for k in range(j+2,len(out))))/(r*(j+1))
    else:
        for j in range(d,-1,-1):
            out[j]=(p[j]-r*sum(comb(k,j)*out[k] for k in range(j+1,len(out))))/(r-lam)
    return tuple(out)

def solve(pair):
    out={ZERO:{Q(1):(Q(1),)}}
    for e in closure():
        if e==ZERO:continue
        lam=Q(0);forcing={}
        for a,b,c in splits(e):
            if a==e or b==e:lam+=c
            else:forcing=ep_add(forcing,ep_mul(out[a],out[b]),c)
        sol={r:particular(lam,r,p) for r,p in forcing.items()}
        sol=ep_add(sol,{lam:(base(e,*pair)-sum(p[0] for p in sol.values()),)})
        out[e]=sol
    ans={}
    for e,c in TARGET.items():
        if valid(e):ans=ep_add(ans,out[e],c)
    return ans,out

def evaluate(ep,t):return sum(sum(c*t**j for j,c in enumerate(p))*r**t for r,p in ep.items())
if __name__=='__main__':
    for pair in [(0,1),(0,2)]:
        ans,allsol=solve(pair)
        print(pair, sorted(ans.items()),flush=True)
        for t,value,ratio,v in evolve(closure(),*pair,16):
            assert evaluate(ans,t)/16**t==value
            for e in v:assert evaluate(allsol[e],t)==v[e]
        print('all moment checks passed',flush=True)
