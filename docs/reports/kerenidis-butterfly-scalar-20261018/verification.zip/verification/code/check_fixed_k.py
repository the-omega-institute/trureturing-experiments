"""Exact finite controls for the analytic fixed-k asymptotic theorem.

Checks Gaussian fixed moments against every transition in the two delivered
closures, compares with certified leading coefficients, and evaluates the
Wick contraction directly from Fock-derived RDMs through k=8. These finite
checks support, but do not replace, the all-k proof in the note.
"""
from collections import defaultdict
from fractions import Fraction as Q
from math import factorial
from pathlib import Path
import json

from general_recursion import Recurrence
from input_state import spread_rdm, haar
from check_haar import fock_rdm


def gaussian(e, q):
    marks = e[4*q:]
    if sum(marks) not in (0, 2):
        raise AssertionError(marks)
    value = Q(1)
    if sum(marks):
        if marks not in ((1, 0, 1, 0), (0, 1, 0, 1)):
            return Q(0)
        value /= q
    for row in range(2):
        for col in range(q):
            a, b = e[row*q+col], e[(row+2)*q+col]
            if a != b:
                return Q(0)
            value *= Q(factorial(a), q**a)
    return value


def fixed_moments():
    reports = []
    certificates = json.loads(Path('results/moment-certificate.json').read_text())
    for cert in certificates:
        q, k = cert['q'], cert['k']
        model = Recurrence(q, k)
        limits = {e: gaussian(e, q) for e in model.keys}
        for e in model.keys:
            marked = sum(e[4*q:]) == 2
            scale = 2 if marked else 1
            rhs = scale * sum(c*limits[a]*limits[b] for a,b,c in model.splits(e))
            assert rhs == limits[e], (q, e, rhs, limits[e])
            if sum(e) > 2:
                diagonal = scale * sum(c for a,b,c in model.splits(e) if a == e or b == e)
                assert diagonal <= Q(3,4)
                if sum(e) > 4:
                    assert diagonal < Q(3,4)
        # Existing exact all-depth solutions must have precisely these limits.
        for case in cert['cases']:
            for e, terms in zip(model.keys, case['moments']):
                scale = 2 if sum(e[4*q:]) else 1
                limit = Q(0)
                for term in terms:
                    base = scale * Q(term['base'])
                    polynomial = list(map(Q, term['polynomial']))
                    if not any(polynomial):
                        continue
                    if base == 1:
                        assert len(polynomial) == 1
                        limit += polynomial[0]
                    else:
                        assert 0 <= base <= Q(3,4)
                        if base == Q(3,4):
                            assert len(polynomial) == 1
                assert limit == limits[e], (q, case['readout'], e)
        contraction = q**5 * sum(c*limits[e] for e,c in model.target.items())
        assert contraction == 2*k*(k*k-k+3)
        reports.append(dict(q=q, k=k, fixed_identities=len(model.keys),
                            certified_cases=len(cert['cases']), scaled_limit=str(contraction)))
    return reports


def wick_controls():
    reports = []
    for q, k in ((4,2), (8,2), (8,4), (16,2), (16,4), (16,6), (16,8)):
        pp, r = spread_rdm(q,k)
        ids = {pair:a for a,pair in enumerate(pp)}
        # Confirm the input matrix against independent Fock annihilation.
        from input_state import input_rdm
        assert input_rdm(q,k)[1] == fock_rdm(q,k)
        # S[c,u,v] is R_{0c,uv} with antisymmetric second pair.
        S = {}
        for c in range(1,q):
            for (a,b), value in r.items():
                if a == ids[0,c]:
                    u,v = pp[b]
                    S[c,u,v] = value
                    S[c,v,u] = -value
        # Wick's two Y-pairings, evaluated by direct summation of J coefficients.
        wick = Q(0)
        for (c,u,v), value in S.items():
            wick += value*S.get((c,u,v),0)
            if c == v:
                wick += value*sum(S.get((d,u,d),0) for d in range(1,q))
        rownorm = sum(value**2 for (a,b),value in r.items() if 0 in pp[a])
        gamma = defaultdict(Q)
        for (c,u,v), value in S.items():
            if c == v:
                gamma[u] += value
        gamma_square = sum(value**2 for value in gamma.values())
        assert rownorm == Q(k*(k+2),4*q)
        assert gamma_square == Q(k*(k-1)**2,2*q)
        assert wick == 2*rownorm+gamma_square
        limit = 4*q*wick
        assert limit == 2*k*(k*k-k+3)
        reports.append(dict(q=q,k=k,wick_numerator=str(wick),scaled_limit=str(limit)))
    return reports


def haar_bound_controls():
    count = 0
    for n in (4,8,16,32,64,128):
        for k in range(2,n//2+1,2):
            positive = Q(2*k*((k*k-k+3)*(n-2*k)+7*k-6),n**4*(n*n-1))
            assert positive == haar(n,k) and positive > 0
            for gamma in (Q(1,4),Q(1,3),Q(2,5),Q(49,100)):
                if k <= gamma*n:
                    assert Q(11,6)*(1-2*gamma)*Q(k**3,n**5) <= positive <= Q(8,3)*Q(k**3,n**5)
                    count += 1
    return dict(positivity_sizes=[4,8,16,32,64,128], sparse_bound_cases=count)


if __name__ == '__main__':
    report = dict(status='passed', fixed_moments=fixed_moments(), wick_controls=wick_controls(),
                  haar_bounds=haar_bound_controls())
    Path('results/fixed-k-check.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
