"""Exact first-layer Fourier reduction; no layer recurrence used."""
from fractions import Fraction as Q
from itertools import combinations, product
from functools import lru_cache
from math import factorial

LOW=list(combinations(range(4),2))
def chi(a,b):return (-1)**((a&b).bit_count())
def det(a,b,s,t):return chi(a,s)*chi(b,t)-chi(a,t)*chi(b,s)
C={(a,b,u,v):Q((det(a,b,0,1)+det(a,b,2,3))*(det(u,v,0,1)+det(u,v,2,3)),2)-Q(sum(det(a,b,s,t)*det(u,v,s,t) for s,t in LOW),4) for a,b,u,v in product(range(4),repeat=4)}
assert all(x.denominator==1 for x in C.values())
C={key:int(value) for key,value in C.items()}

def prefixes(n):
    return [[sum(chi(h,r) for r in range(b)) for h in range(n//4)] for b in range(1,n//4+1)]

def rnum(c,u,v,S):
    # n**2 R_{0c,uv}; the second pair is oriented, not necessarily sorted.
    a,b,d=c&3,u&3,v&3
    val=C[0,a,b,d]*S[(c^u^v)>>2]
    if b==0 and a==d:val+=4*S[u>>2]*S[(c^v)>>2]
    if d==0 and a==b:val-=4*S[v>>2]*S[(c^u)>>2]
    return val

class Integrator:
    def __init__(self,n,pair):
        self.n=n;self.pair=pair;self.K=n.bit_length()-1
        self.paths={}
        for row in range(2):
            for col in range(n):
                cur=col;sgn=1;phase=[];angle=[]
                for ell in range(self.K):
                    bit=1<<ell
                    phase.append(ell*n+cur)
                    gate=ell*(n//2)+(cur%bit)+(cur//(2*bit))*bit
                    flip=bool((cur^pair[row])&bit)
                    angle.append(2*gate+flip)
                    if flip:
                        if cur&bit:sgn=-sgn
                        cur^=bit
                assert cur==pair[row]
                self.paths[row,col]=(sgn,phase,angle)
        self.cache={}
    def moment(self,ket,bra):
        # ket,bra are sorted tuples of (row,column) amplitude labels.
        key=(tuple(sorted(ket)),tuple(sorted(bra)))
        if key in self.cache:return self.cache[key]
        phases={};angles={};sign=1
        for labels,pm in ((ket,1),(bra,-1)):
            for label in labels:
                s,pp,aa=self.paths[label];sign*=s
                for p in pp:phases[p]=phases.get(p,0)+pm
                for a in aa:angles[a]=angles.get(a,0)+1
        if any(phases.values()):value=Q(0)
        else:
            value=Q(sign)
            for gate in {a//2 for a in angles}:
                c,s=angles.get(2*gate,0),angles.get(2*gate+1,0)
                if c%2 or s%2:value=Q(0);break
                a,b=c//2,s//2
                value*=Q(factorial(2*a)*factorial(2*b),4**(a+b)*factorial(a)*factorial(b)*factorial(a+b))
        self.cache[key]=value
        return value
    def wedge_product(self,A,B,D,E):
        # E[z_A conj(z_B) conj(z_D) z_E].
        pairs=(A,E,B,D);ans=Q(0)
        for mask in range(16):
            ket=[];bra=[];sgn=1
            for t,(a,b) in enumerate(pairs):
                if mask>>t&1:a,b=b,a;sgn=-sgn
                (ket if t<2 else bra).extend(((0,a),(1,b)))
            ans+=sgn*self.moment(ket,bra)
        return ans

def exact_all(n,pair,verbose=False):
    SS=prefixes(n);total=[Q(0) for _ in SS];I=Integrator(n,pair);counts=[0,0]
    # Frequencies phi_0+phi_c-phi_u-phi_v: three distinct nonzero columns.
    for c in range(1,n):
        for u,v in combinations((a for a in range(1,n) if a!=c),2):
            cc=[rnum(c,u,v,S) for S in SS]
            if not any(cc):continue
            weight=I.wedge_product((0,c),(u,v),(0,c),(u,v))
            for b,x in enumerate(cc):total[b]+=x*x*weight
            counts[0]+=1
        if verbose and c%8==0:print('disjoint',n,pair,c,len(I.cache),flush=True)
    # Frequencies phi_0-phi_v; orient the second pair as (c,v).
    # Reversing (u,v) changes both R and z, leaving their product unchanged.
    for v in range(1,n):
        cs=[c for c in range(1,n) if c!=v]
        RR={c:[rnum(c,c,v,S) for S in SS] for c in cs}
        for ci,c in enumerate(cs):
            for d in cs[ci:]:
                cc=[a*b for a,b in zip(RR[c],RR[d])]
                if not any(cc):continue
                weight=I.wedge_product((0,c),(c,v),(0,d),(d,v))*(1 if c==d else 2)
                for b,x in enumerate(cc):total[b]+=x*weight
                counts[1]+=1
        if verbose and v%8==0:print('shared',n,pair,v,len(I.cache),flush=True)
    return [2*x/n**4 for x in total],dict(disjoint_groups=counts[0],shared_products=counts[1],moments=len(I.cache))

if __name__=='__main__':
    import sys,json,time
    from pathlib import Path
    from input_state import haar
    n=int(sys.argv[1]);pair=tuple(map(int,sys.argv[2:4]));start=time.time()
    vals,counts=exact_all(n,pair,True)
    rows=[dict(n=n,k=2*b+2,pair=pair,V=str(v),H=str(haar(n,2*b+2)),ratio=str(v/haar(n,2*b+2)),decimal=float(v/haar(n,2*b+2))) for b,v in enumerate(vals)]
    out=dict(n=n,pair=pair,seconds=time.time()-start,counts=counts,rows=rows)
    (Path(__file__).resolve().parents[1]/'results'/('finite-n%d-%d%d.json'%(n,*pair))).write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out),flush=True)
