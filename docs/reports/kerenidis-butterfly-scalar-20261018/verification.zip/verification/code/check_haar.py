"""Independent finite exact checks of the general-even-k Haar normalisation."""
from collections import defaultdict
from itertools import combinations,product
from fractions import Fraction as Q
import json
from pathlib import Path
from input_state import pairs,input_rdm,spread_rdm,haar

def annihilate(mask,a):
    if not mask>>a&1:return None
    return mask^(1<<a),(-1)**((mask&((1<<a)-1)).bit_count())
def fock_rdm(n,k):
    states=[]
    for choices in product((0,1),repeat=k//2):
        mask=sum((3<<(4*b+2*c)) for b,c in enumerate(choices));states.append(mask)
    vectors=[]
    for a,b in pairs(n):
        v=defaultdict(int)
        for state in states:
            x=annihilate(state,a)
            if x is None:continue
            y=annihilate(x[0],b)
            if y is None:continue
            v[y[0]]+=x[1]*y[1]
        vectors.append(v)
    r={}
    for i,x in enumerate(vectors):
        for j,y in enumerate(vectors):
            v=Q(sum(a*y.get(s,0) for s,a in x.items()),2**(k//2))
            if v:r[i,j]=v
    return r

def finite_norms(n,k):
    p,r=spread_rdm(n,k);ids={v:i for i,v in enumerate(p)}
    b={ (i,j):((0 in p[i])-(0 in p[j]))*v for (i,j),v in r.items() if (0 in p[i])!=(0 in p[j]) }
    norm=sum(v*v for v in b.values());gamma=defaultdict(Q)
    for (i,j),v in b.items():
        a,c=p[i];d,e=p[j]
        for x,y,s in [(a,c,1),(c,a,-1)]:
            for z,w,t in [(d,e,1),(e,d,-1)]:
                if y==w:gamma[x,z]+=s*t*v
    gnorm=sum(v*v for v in gamma.values())
    return norm,gnorm

def main():
    rows=[]
    for n in (4,8,16):
        for k in range(2,n//2+1,2):
            assert fock_rdm(n,k)==input_rdm(n,k)[1]
            b,g=finite_norms(n,k)
            bf=Q(k*((k+2)*n-2*k*k+3*k-6),2*n*n)
            gf=Q(k*(k-1)**2*(n-2*k),n*n)
            assert (b,g)==(bf,gf),(n,k,b,g,bf,gf)
            h=(4*b+2*g)/(n*n*(n*n-1));assert h==haar(n,k)
            rows.append(dict(n=n,k=k,B_norm_squared=str(b),Gamma_norm_squared=str(g),Haar=str(h)))
    Path('results/haar-check.json').write_text(json.dumps(dict(status='passed',method='Fock annihilation; exact Walsh exterior matrix; direct commutator and contraction',rows=rows),indent=2)+'\n')
    print(json.dumps(dict(status='passed',cases=len(rows))))
if __name__=='__main__':main()
