"""Pair-retaining exact degree-eight recurrence for an arbitrary finite input RDM."""
from collections import defaultdict
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
from math import comb
from input_state import spread_rdm
from pair_recursion import angular
from solve_recursion import ep_add, ep_mul, particular, evaluate

class Recurrence:
    def __init__(self,q,k):
        self.q=q;self.k=k;self.N=4*q+4;self.zero=(0,)*self.N
        self.rows=tuple(tuple(range(r*q,(r+1)*q))+tuple(range((r+2)*q,(r+3)*q))+(4*q+r,4*q+2+r) for r in range(2))
        self.pairs,self.rho=spread_rdm(q,k)
        # L = sum rho_AB z_A conj(z_B); derivative = i T / m^2.
        wedge=[{self.mono(a,q+b):Q(1),self.mono(b,q+a):Q(-1)} for a,b in self.pairs]
        deriv=[]
        for a,b in self.pairs:
            d=defaultdict(Q)
            if a==0:
                d[self.mono(4*q,q+b)]+=1;d[self.mono(b,4*q+1)]-=1
            if b==0:
                d[self.mono(a,4*q+1)]+=1;d[self.mono(4*q,q+a)]-=1
            deriv.append(dict(d))
        term=defaultdict(Q)
        for (a,b),v in self.rho.items():
            for e,c in self.mul(deriv[a],self.conjugate(wedge[b])).items():term[e]+=v*c
            for e,c in self.mul(wedge[a],self.conjugate(deriv[b])).items():term[e]-=v*c
        term={e:c for e,c in term.items() if c}
        grouped=defaultdict(dict)
        for e,c in term.items():grouped[self.col_imbalance(e)][e]=c
        target=defaultdict(Q)
        for sig,left in grouped.items():
            right=grouped.get(tuple(-x for x in sig),{})
            for e,c in self.mul(left,right).items():
                if self.valid(e):target[e]-=c
        self.target={e:c for e,c in target.items() if c}
        self.gradient=term
        self.splits=lru_cache(None)(self._splits)
        self.path=lru_cache(None)(self._path)
        self.base=lru_cache(None)(self._base)
        seen={self.zero};todo=list(self.target);seen.update(todo)
        while todo:
            e=todo.pop()
            for a,b,c in self.splits(e):
                for v in (a,b):
                    if v not in seen:seen.add(v);todo.append(v)
        self.keys=sorted(seen,key=lambda e:(sum(e),sum(e[4*q:]),e))
    def mono(self,*idx):
        v=[0]*self.N
        for i in idx:v[i]+=1
        return tuple(v)
    def conj(self,e):
        q=self.q
        return e[2*q:4*q]+e[:2*q]+e[4*q+2:]+e[4*q:4*q+2]
    def conjugate(self,p):return {self.conj(e):c for e,c in p.items()}
    def mul(self,p,r):
        out=defaultdict(Q)
        for e,c in p.items():
            for f,d in r.items():out[tuple(a+b for a,b in zip(e,f))]+=c*d
        return {e:c for e,c in out.items() if c}
    def col_imbalance(self,e):
        q=self.q
        return tuple(e[c]+e[q+c]-e[2*q+c]-e[3*q+c]+(e[4*q]+e[4*q+1]-e[4*q+2]-e[4*q+3] if c==0 else 0) for c in range(q))
    def valid(self,e):
        q=self.q
        for r in range(2):
            if sum(e[q*r:q*(r+1)])+e[4*q+r]!=sum(e[q*(r+2):q*(r+3)])+e[4*q+2+r]:return False
        return not any(self.col_imbalance(e))
    def _splits(self,e):
        q=self.q;active=[i for i in range(4*q) if e[i]];result=[]
        for vals in product(*(range(e[i]+1) for i in active)):
            a=list(e);b=[0]*self.N;c=Q(1)
            for i,v in zip(active,vals):a[i]=v;b[i]=e[i]-v;c*=comb(e[i],v)
            a=tuple(a);b=tuple(b)
            if not self.valid(a) or not self.valid(b):continue
            for row in self.rows:c*=angular(sum(a[i] for i in row),sum(b[i] for i in row))
            if c:result.append((a,b,c))
        return tuple(result)
    def _path(self,out,inp):
        q=self.q;K=q.bit_length()-1;cur=inp;sgn=1;ang=[0]*(q*K);phase=[0]*(q*K)
        for l in range(K):
            stride=1<<l;phase[q*l+cur]+=1;base=cur&~stride
            gate=l*(q//2)+(base%stride)+(base//(2*stride))*stride
            changed=bool((cur^out)&stride);ang[2*gate+int(changed)]+=1
            if changed:
                if cur&stride:sgn=-sgn
                cur^=stride
        return sgn,tuple(ang),tuple(phase)
    def _base(self,e,i,j):
        q=self.q;K=q.bit_length()-1;ang=[0]*(q*K);phase=[0]*(q*K);sgn=1
        for v,power in enumerate(e):
            if not power:continue
            if v<4*q:col=v%q;row=i if (v//q)%2==0 else j;bar=v>=2*q
            else:col=0;row=i if v%2==0 else j;bar=v>=4*q+2
            s,a,p=self.path(row,col);sgn*=s**power
            for t in range(q*K):ang[t]+=power*a[t];phase[t]+=(-1 if bar else 1)*power*p[t]
        if any(phase):return Q(0)
        out=Q(sgn)
        for t in range(0,q*K,2):out*=angular(ang[t],ang[t+1])
        return out
    def solve(self,pair):
        out={self.zero:{Q(1):(Q(1),)}}
        for e in self.keys:
            if e==self.zero:continue
            lam=Q(0);forcing={}
            for a,b,c in self.splits(e):
                if a==e or b==e:lam+=c
                else:forcing=ep_add(forcing,ep_mul(out[a],out[b]),c)
            sol={r:particular(lam,r,p) for r,p in forcing.items()}
            sol=ep_add(sol,{lam:(self.base(e,*pair)-sum(p[0] for p in sol.values()),)})
            out[e]=sol
        ans={}
        for e,c in self.target.items():ans=ep_add(ans,out[e],c)
        scaled={2*r:tuple(self.q**5*c for c in p) for r,p in ans.items()}
        return scaled,out

if __name__=='__main__':
    for q,k in [(4,2),(8,4)]:
        model=Recurrence(q,k)
        print('size',q,k,len(model.gradient),len(model.target),len(model.keys),sum(len(model.splits(e)) for e in model.keys),flush=True)
        for pair in [(0,1),(0,2),(1,3)]:
            ans,sol=model.solve(pair)
            print('solution',q,k,pair,sorted((str(r),[str(c) for c in p]) for r,p in ans.items()),flush=True)
