"""Verify every coefficient identity, base moment, contraction and bound.
No solving of recurrences occurs in this verifier.
"""
from pathlib import Path
from fractions import Fraction as Q
from math import comb
import json
from general_recursion import Recurrence
from input_state import haar

def clean(ep):
    out={}
    for r,p in ep.items():
        p=list(p)
        while p and not p[-1]:p.pop()
        if p:out[r]=tuple(p)
    return out
def add(ep,other,c=Q(1)):
    out={r:list(p) for r,p in ep.items()}
    for r,p in other.items():
        vals=out.setdefault(r,[])
        vals.extend([Q(0)]*max(0,len(p)-len(vals)))
        for j,v in enumerate(p):vals[j]+=c*v
    return clean(out)
def multiply(ep,other):
    out={}
    for r,p in ep.items():
        for s,pp in other.items():
            poly=[Q(0)]*(len(p)+len(pp)-1)
            for i,v in enumerate(p):
                for j,w in enumerate(pp):poly[i+j]+=v*w
            out=add(out,{r*s:poly})
    return out
def shifted(ep):return clean({r:[r*sum(p[j]*comb(j,i) for j in range(i,len(p))) for i in range(len(p))] for r,p in ep.items()})
def decode(terms):return clean({Q(x['base']):tuple(map(Q,x['polynomial'])) for x in terms})
def at(ep,t):return sum(r**t*sum(c*t**j for j,c in enumerate(p)) for r,p in ep.items())

def main():
    certs=json.loads(Path('results/moment-certificate.json').read_text());count=0;cases=[];k2_bases={};k4_scalars={}
    for cert in certs:
        q,k=cert['q'],cert['k'];model=Recurrence(q,k);ids={e:i for i,e in enumerate(model.keys)}
        assert len(model.keys)==len(cert['moments'])
        assert cert['target']==[[ids[e],str(c)] for e,c in model.target.items()]
        for record,e in zip(cert['moments'],model.keys):
            assert tuple(record['exponents'])==e
            assert record['transitions']==[[ids[a],ids[b],str(c)] for a,b,c in model.splits(e)]
        for case in cert['cases']:
            pair=tuple(case['readout']);mom=[decode(x) for x in case['moments']]
            for idx,e in enumerate(model.keys):
                assert at(mom[idx],0)==model.base(e,*pair)
                rhs={}
                for a,b,c in cert['moments'][idx]['transitions']:rhs=add(rhs,multiply(mom[a],mom[b]),Q(c))
                assert shifted(mom[idx])==rhs,(q,k,pair,idx)
                count+=1
            contraction={}
            for idx,c in cert['target']:contraction=add(contraction,mom[idx],Q(c))
            scaled={2*r:tuple(q**5*c for c in p) for r,p in contraction.items()}
            assert scaled==decode(case['scaled_variance'])
            # Iterative checks are supplementary to the coefficient identities.
            values={e:model.base(e,*pair) for e in model.keys}
            for t in range(13):
                assert all(values[e]==at(mom[ids[e]],t) for e in model.keys)
                values={e:sum(c*values[a]*values[b] for a,b,c in model.splits(e)) for e in model.keys}
            if k==2:k2_bases[pair]=[model.base(e,*pair) for e in model.keys]
            else:k4_scalars[pair]=scaled
            cases.append(dict(q=q,k=k,readout=pair,moments=len(model.keys),scaled_variance=case['scaled_variance']))
    assert k2_bases[1,2]==k2_bases[2,3]==k2_bases[0,1]
    assert k2_bases[1,3]==k2_bases[0,2]
    assert k4_scalars[0,2]==k4_scalars[1,3]
    assert k4_scalars[0,1]==k4_scalars[0,3]==k4_scalars[1,2]==k4_scalars[2,3]
    # Uniform k=4 bounds on t>=0, proved by geometric tails in the note.
    A=k4_scalars[0,1];B=k4_scalars[0,2]
    for t in range(3):
        n=8*2**t;h=n**5*haar(n,4)
        assert Q(1,4)<at(B,t)/h<at(A,t)/h<1
    lower=120-Q(891,8)*Q(3,4)**2-Q(287,4)*Q(1,2)**2-Q(323,8)*Q(1,4)**2
    assert lower==Q(2361,64) and lower>30
    upper_bracket=Q(891,8)-Q(375,2)*Q(2,3)**3-Q(533,64)*Q(3,4)**3-Q(8567,128)*Q(3,8)**3
    assert upper_bracket>0
    assert Q(645,4)-Q(1411,8)*Q(3,4)>0
    report=dict(status='passed',initial_and_recurrence_identity_pairs=count,iterations_per_case=13,k2_disjoint_base_equalities='all 198 moments in each comparison',k4_uniform_ratio_bounds=['1/4','1'],k4_tail_lower=str(lower),k4_upper_bracket_at_3=str(upper_bracket),cases=cases)
    Path('results/certificate-verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({key:value for key,value in report.items() if key!='cases'}))
if __name__=='__main__':main()
