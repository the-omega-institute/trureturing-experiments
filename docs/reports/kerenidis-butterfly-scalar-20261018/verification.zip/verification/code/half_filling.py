"""Five-subspace transfer for k=n/2, n=4*2**r, fixed low readout."""
from fractions import Fraction as Q
from itertools import product
from functools import lru_cache
from math import factorial
from fast_scalar import Integrator,C

# Kernel of (a,b) -> a*C_high + b*U_high in F_2^r.
SPACES=(frozenset((0,1,2,3)),frozenset((0,1)),frozenset((0,2)),frozenset((0,3)),frozenset((0,)))
REPS=((0,0),(0,1),(1,0),(1,1),(1,2))
def bit(x,f):return (x&f).bit_count()%2
def classes(K):
    todo=set(range(4));out=[]
    while todo:
        a=min(todo);cl={a^x for x in K};out.append(cl);todo-=cl
    return out

def angular(c,s):
    if c%2 or s%2:return Q(0)
    a,b=c//2,s//2
    return Q(factorial(2*a)*factorial(2*b),4**(a+b)*factorial(a)*factorial(b)*factorial(a+b))

def labels(mask):
    ket=[[],[]];bra=[[],[]]
    for t,(a,b) in enumerate(((0,1),(2,3),(0,1),(2,3))):
        if mask>>t&1:a,b=b,a
        target=ket if t<2 else bra
        target[0].append(a);target[1].append(b)
    return ket,bra

def transfer(mask):
    ket,bra=labels(mask);T=[[Q(0) for _ in SPACES] for _ in SPACES]
    for i,K in enumerate(SPACES):
        for f in range(4):
            new=frozenset(x for x in K if bit(x,f)==0);j=SPACES.index(new)
            if any(sum(x in cl for x in ket[row])!=sum(x in cl for x in bra[row]) for row in range(2) for cl in classes(new)):continue
            w=Q(1)
            for row in range(2):
                for cl in classes(K):
                    aa=[x for x in ket[row]+bra[row] if x in cl]
                    s=sum(bit(x,f) for x in aa);w*=angular(len(aa)-s,s)
            T[i][j]+=w
    return T

def endpoint(mask,pair):
    ket,bra=labels(mask);out=[]
    for K,(ch,uh) in zip(SPACES,REPS):
        I=Integrator(16,pair)
        I.paths={key:(sgn,pp[:2],aa[:2]) for key,(sgn,pp,aa) in I.paths.items()}
        value=Q(0)
        for cl,ul in product(range(4),repeat=2):
            vl=cl^ul;coef=C[0,cl,ul,vl]
            if not coef:continue
            # exclude full u=0 or v=c xor u=0; c_low cannot be zero.
            if ul==0 and 2 in K:continue
            if vl==0 and 3 in K:continue
            cols=(0,4*ch+cl,4*uh+ul,4*(ch^uh)+vl)
            ke=[(row,cols[x]) for row in range(2) for x in ket[row]]
            br=[(row,cols[x]) for row in range(2) for x in bra[row]]
            value+=coef**2*I.moment(ke,br)*(-1)**mask.bit_count()
        out.append(value)
    return out

if __name__=='__main__':
    import sys,json
    from pathlib import Path
    from fast_scalar import exact_all
    pair=tuple(map(int,sys.argv[1:3]))
    print('pair',pair,flush=True)
    for r in range(4):
        v=Q(0)
        for mask in range(16):
            T=transfer(mask);L=endpoint(mask,pair);vec=[Q(1)]+[Q(0)]*4
            for _ in range(r):vec=[sum(vec[i]*T[i][j] for i in range(5)) for j in range(5)]
            v+=sum(x*y for x,y in zip(vec,L))
        n=4*2**r;v/=16*n*n
        ref=exact_all(n,pair)[0][-1]
        print(r,n,str(v),str(ref),v==ref,flush=True)
        assert v==ref
    cert=dict(pair=pair,spaces=[sorted(x) for x in SPACES],matrices=[[[str(x) for x in row] for row in transfer(m)] for m in range(16)],endpoints=[[str(x) for x in endpoint(m,pair)] for m in range(16)])
    (Path(__file__).resolve().parents[1]/'results'/('half-filling-%d%d.json'%pair)).write_text(json.dumps(cert,indent=2)+'\n')
