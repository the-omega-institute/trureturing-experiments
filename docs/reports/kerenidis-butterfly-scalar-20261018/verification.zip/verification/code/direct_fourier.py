"""Direct full-n Fourier/angle integration, without a layer recurrence."""
from collections import defaultdict
from fractions import Fraction as Q
from functools import lru_cache
from itertools import product
from math import factorial
import json
from pathlib import Path
from general_recursion import Recurrence
from input_state import haar

@lru_cache(None)
def path(n,row,col):
    """Unique path through increasing strides; independent path implementation."""
    phase=[0]*(n*(n.bit_length()-1));angle=[0]*len(phase);sgn=1;v=col
    for layer in range(n.bit_length()-1):
        step=2**layer;phase[n*layer+v]=1
        gates=[x for x in range(n) if x&step==0]
        gate=layer*(n//2)+gates.index(v&~step)
        flip=(v&step)!=(row&step)
        angle[2*gate+flip]=1
        if flip:
            if v&step:sgn=-sgn
            v^=step
    assert v==row
    return tuple(phase),tuple(angle),sgn
@lru_cache(None)
def integral(angle):
    v=Q(1)
    for c,s in zip(angle[::2],angle[1::2]):
        if c%2 or s%2:return Q(0)
        a,b=c//2,s//2
        v*=Q(factorial(2*a)*factorial(2*b),4**(a+b)*factorial(a)*factorial(b)*factorial(a+b))
    return v

def direct(model,n,pair):
    q=model.q;m=n//q;terms=defaultdict(lambda:defaultdict(Q))
    for e,coef in model.gradient.items():
        options=[]
        for v,power in enumerate(e):
            if v<4*q:
                row=pair[(v//q)%2];bar=v>=2*q;cols=range(v%q,n,q)
            else:row=pair[v%2];bar=v>=4*q+2;cols=[0]
            for _ in range(power):
                opts=[]
                for col in cols:
                    p,a,s=path(n,row,col);opts.append((tuple(-x for x in p) if bar else p,a,s))
                options.append(opts)
        for factors in product(*options):
            p=tuple(map(sum,zip(*(x[0] for x in factors))))
            a=tuple(map(sum,zip(*(x[1] for x in factors))))
            c=coef
            for x in factors:c*=x[2]
            terms[p][a]+=c
    terms={p:{a:c for a,c in poly.items() if c} for p,poly in terms.items()};terms={p:poly for p,poly in terms.items() if poly}
    value=Q(0);checks=0
    for p,left in terms.items():
        right=terms.get(tuple(-x for x in p),{})
        for a,c in left.items():
            for b,d in right.items():
                value-=c*d*integral(tuple(x+y for x,y in zip(a,b)));checks+=1
    return value/m**4,dict(fourier_frequencies=len(terms),angle_products=checks)

def main():
    rows=[]
    for q,k,cases in [(4,2,[(4,(1,3)),(8,(1,2)),(8,(1,3)),(16,(1,3))]),(8,4,[(8,(0,1)),(8,(1,3)),(16,(0,1)),(16,(1,3))])]:
        model=Recurrence(q,k)
        for n,pair in cases:
            v,counts=direct(model,n,pair)
            moments={e:model.base(e,*pair) for e in model.keys}
            for _ in range((n//q).bit_length()-1):moments={e:sum(c*moments[a]*moments[b] for a,b,c in model.splits(e)) for e in model.keys}
            expected=sum(c*moments[e] for e,c in model.target.items())/(n//q)**4
            assert v==expected,(q,k,n,pair,v,expected)
            row=dict(n=n,k=k,readout=pair,variance=str(v),haar=str(haar(n,k)),ratio=str(v/haar(n,k)),**counts)
            rows.append(row);print(row,flush=True)
    Path('results/direct-fourier.json').write_text(json.dumps(dict(status='passed',cases=rows),indent=2)+'\n')
if __name__=='__main__':main()
