"""Exact unnormalised two-particle RDM and Walsh spreading; standard library."""
from fractions import Fraction as Q
from itertools import combinations

def pairs(n): return list(combinations(range(n),2))
def sign(a,b): return (-1)**((a&b).bit_count())
def input_rdm(n,k):
    assert k%2==0 and 2<=k<=n//2
    p=pairs(n); ids={v:i for i,v in enumerate(p)}; out={}
    for i,(a,b) in enumerate(p):
        if b>=2*k:continue
        if a//4!=b//4:out[i,i]=Q(1,4)
    for block in range(k//2):
        a=ids[(4*block,4*block+1)]; b=ids[(4*block+2,4*block+3)]
        for i in (a,b):
            for j in (a,b):out[i,j]=Q(1,2)
    return p,out

def spread_rdm(n,k):
    p,r=input_rdm(n,k)
    h=[[Q(sign(a,c)*sign(b,d)-sign(a,d)*sign(b,c),n) for c,d in p] for a,b in p]
    hr={}
    for i in range(len(p)):
        for (a,b),v in r.items():
            if h[i][a]:hr[i,b]=hr.get((i,b),Q(0))+h[i][a]*v
    out={}
    for i in range(len(p)):
        for j in range(len(p)):
            x=sum(hr.get((i,b),0)*h[j][b] for b in range(len(p)))
            if x:out[i,j]=x
    return p,out

def haar(n,k):
    return Q(2*k*((k*k-k+3)*n-2*k**3+2*k*k+k-6),n**4*(n*n-1))
if __name__=='__main__':
    for q,k in [(4,2),(8,2),(8,4),(16,6)]:
        p,r=spread_rdm(q,k)
        print(q,k,len(p),len(r),flush=True)
