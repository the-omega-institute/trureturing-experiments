"""Exact Gaussian-rational matrix check of the circuit/polynomial bridge."""
from fractions import Fraction as Q
from pathlib import Path
import json
from general_recursion import Recurrence
from input_state import spread_rdm

class C:
    def __init__(self,a=0,b=0):self.a=Q(a);self.b=Q(b)
    def __add__(self,z):
        if not isinstance(z,C):z=C(z)
        return C(self.a+z.a,self.b+z.b)
    __radd__=__add__
    def __neg__(self):return C(-self.a,-self.b)
    def __sub__(self,z):return self+-z
    def __mul__(self,z):
        if not isinstance(z,C):z=C(z)
        return C(self.a*z.a-self.b*z.b,self.a*z.b+self.b*z.a)
    __rmul__=__mul__
    def __pow__(self,p):
        r=C(1)
        for _ in range(p):r=r*self
        return r
    def conj(self):return C(self.a,-self.b)
    def __eq__(self,z):return isinstance(z,C) and (self.a,self.b)==(z.a,z.b)
    def __repr__(self):return f'({self.a})+i({self.b})'
I=C(0,1)

def matrix(n,seed):
    w=[[C(int(a==b)) for b in range(n)] for a in range(n)]
    phases=[C(1),C(Q(3,5),Q(4,5)),C(Q(5,13),Q(-12,13)),C(Q(-8,17),Q(15,17))]
    cs=[(Q(3,5),Q(4,5)),(Q(5,13),Q(12,13)),(Q(-8,17),Q(15,17))]
    for l in range(n.bit_length()-1):
        w=[[v*phases[(a+2*l+seed)%4] for v in row] for a,row in enumerate(w)]
        for a in range(n):
            if a&(1<<l):continue
            b=a+(1<<l);c,s=cs[(a+l+seed)%3];u,v=w[a],w[b]
            w[a]=[c*x-s*y for x,y in zip(u,v)];w[b]=[s*x+c*y for x,y in zip(u,v)]
    return w

def main():
    cases=[]
    for q,k,ns in [(4,2,(4,8,16)),(8,4,(8,16))]:
        model=Recurrence(q,k)
        for n in ns:
            pp,r=spread_rdm(n,k)
            for seed in (1,2):
                w=matrix(n,seed)
                for i,j in [(0,1),(0,2),(1,2),(1,3),(2,3)]:
                    zz=[w[i][a]*w[j][b]-w[i][b]*w[j][a] for a,b in pp]
                    dd=[I*(w[i][0]*w[j][b]-w[i][b]*w[j][0]) if a==0 else C() for a,b in pp]
                    grad=sum(v*(dd[a]*zz[b].conj()+zz[a]*dd[b].conj()) for (a,b),v in r.items())
                    X=[sum(w[i][c] for c in range(a,n,q)) for a in range(q)]
                    Y=[sum(w[j][c] for c in range(a,n,q)) for a in range(q)]
                    Z=X+Y+[x.conj() for x in X+Y]+[w[i][0],w[j][0],w[i][0].conj(),w[j][0].conj()]
                    poly=C()
                    for e,c in model.gradient.items():
                        term=C(c)
                        for x,power in zip(Z,e):
                            if power:term=term*x**power
                        poly=poly+term
                    reduced=I*poly*Q(1,(n//q)**2)
                    assert grad==reduced and grad.b==0,(n,k,seed,i,j,grad,reduced)
                    cases.append(dict(n=n,k=k,readout=[i,j],assignment=seed))
    Path('results/matrix-bridge.json').write_text(json.dumps(dict(status='passed',arithmetic='Gaussian rationals',cases=cases),indent=2)+'\n')
    print(json.dumps(dict(status='passed',pointwise_checks=len(cases))))
if __name__=='__main__':main()
