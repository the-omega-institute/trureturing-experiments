"""Produce exact all-layer coefficients; verification is a separate program."""
from pathlib import Path
import json
from general_recursion import Recurrence
from solve_recursion import evaluate
from input_state import haar

def encode(ep):return [dict(base=str(r),polynomial=[str(c) for c in p]) for r,p in sorted(ep.items())]
def main():
    certificates=[];tables=[]
    for q,k,pairs in [(4,2,[(0,1),(0,2),(1,2),(1,3),(2,3)]),(8,4,[(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)])]:
        model=Recurrence(q,k);ids={e:i for i,e in enumerate(model.keys)}
        cert=dict(q=q,k=k,moments=[dict(exponents=e,transitions=[[ids[a],ids[b],str(c)] for a,b,c in model.splits(e)]) for e in model.keys],target=[[ids[e],str(c)] for e,c in model.target.items()],cases=[])
        for pair in pairs:
            scaled,sol=model.solve(pair)
            cert['cases'].append(dict(readout=pair,moments=[encode(sol[e]) for e in model.keys],scaled_variance=encode(scaled)))
            for t in range(9):
                n=q*2**t;v=evaluate(scaled,t)/n**5;h=haar(n,k)
                tables.append(dict(k=k,n=n,readout=pair,variance=str(v),haar=str(h),ratio=str(v/h),ratio_decimal=float(v/h)))
        certificates.append(cert)
        print(dict(q=q,k=k,moments=len(model.keys),transitions=sum(len(model.splits(e)) for e in model.keys),cases=len(pairs)),flush=True)
    Path('results/moment-certificate.json').write_text(json.dumps(certificates,separators=(',',':'))+'\n')
    Path('results/exact-tables.json').write_text(json.dumps(tables,indent=2)+'\n')
if __name__=='__main__':main()
