"""Exact half-filling proof certificate and cross-checks; standard library only.

The linear annihilator and five initial values prove the closed formula for all
depths once the five-state circuit reduction in note.tex is established.
"""
from fractions import Fraction as Q
from itertools import combinations
from pathlib import Path
import json

from half_filling import transfer, endpoint
from fast_scalar import rnum, prefixes, exact_all
from input_state import spread_rdm, haar
from general_recursion import Recurrence
from solve_recursion import evaluate

BASE = Path(__file__).resolve().parents[1]
PAIRS = list(combinations(range(4), 2))
AFAMILY = {(0, 1), (0, 3), (1, 2), (2, 3)}

def mm(a, b):
    return [[sum(x*y for x,y in zip(row,col)) for col in zip(*b)] for row in a]

def identity():
    return [[Q(i == j) for j in range(5)] for i in range(5)]

def mv(a, v):
    return [sum(x*y for x,y in zip(row,v)) for row in a]

def closed(r, pair):
    a, b = (Q(535,64), Q(57,8)) if pair in AFAMILY else (Q(161,64), Q(105,32))
    return Q(273,64)*Q(9,8)**r-Q(7,2)+a*Q(9,16)**r-b*Q(1,2)**r

def grouped(pair):
    ma = [[9,1,9,1,0],[0,8,0,0,8],[0,0,18,0,2],[0,0,0,8,8],[0,0,0,0,16]]
    mb = [[9,1,0,0,0],[0,8,0,0,0],[0]*5,[0]*5,[0]*5]
    mc = [[9,1,0,1,0],[0,8,0,0,0],[0]*5,[0,0,0,8,0],[0]*5]
    matrices = [[[Q(x,16) for x in row] for row in a] for a in (ma,mb,mc)]
    if pair in AFAMILY:
        terminals = [[Q(9,8),Q(53,8),Q(49,64),Q(49,16),Q(7,2)],
                     [Q(3,4),Q(15,4),Q(0),Q(0),Q(0)],
                     [Q(1,8),Q(5,8),Q(0),Q(1,16),Q(0)]]
    else:
        terminals = [[Q(3,16),Q(77,32),Q(49,64),Q(361,64),Q(7,2)],
                     [-Q(3,8),Q(19,16),Q(0),Q(0),Q(0)],
                     [Q(3,16),Q(13,32),Q(0),Q(41,64),Q(0)]]
    return matrices, terminals

def half_certificate():
    reports = []
    groups = ((0,15),(1,2,4,7,8,11,13,14),(3,12),(5,10),(6,9))
    swap = (0,1,3,2,4)
    for pair in PAIRS:
        matrices, terminals = grouped(pair)
        raw = []
        for group in groups:
            t = transfer(group[0])
            assert all(transfer(mask) == t for mask in group)
            l = [sum(endpoint(mask,pair)[i] for mask in group) for i in range(5)]
            raw.append(([[4*x for x in row] for row in t],l))
        for idx in (0,1,2):
            assert raw[idx][0] == matrices[idx]
        assert [[raw[3][0][swap[i]][swap[j]] for j in range(5)] for i in range(5)] == matrices[0]
        assert [[raw[4][0][swap[i]][swap[j]] for j in range(5)] for i in range(5)] == matrices[2]
        combined = [[raw[0][1][i]+raw[3][1][swap[i]] for i in range(5)],
                    raw[1][1],
                    [raw[2][1][i]+raw[4][1][swap[i]] for i in range(5)]]
        # State index 2 of M_C is unreachable from the initial row.
        combined[2][2] = Q(0)
        assert combined == terminals, (pair,combined,terminals)
        for matrix in matrices:
            prod = identity()
            for root in (Q(0),Q(1),Q(1,2),Q(9,16),Q(9,8)):
                factor = [[matrix[i][j]-root*Q(i==j) for j in range(5)] for i in range(5)]
                prod = mm(prod,factor)
            assert all(x == 0 for row in prod for x in row)
        vectors = terminals
        for r in range(5):
            assert sum(v[0] for v in vectors) == closed(r,pair)
            vectors = [mv(a,v) for a,v in zip(matrices,vectors)]
        for r in range(1,10):
            n=4*2**r
            assert closed(r,pair)/(n**4*haar(n,n//2)) > Q(1,4)
        reports.append(dict(pair=pair,matrices=[[[str(x) for x in row] for row in a] for a in matrices],
                            terminals=[[str(x) for x in v] for v in terminals],
                            annihilator_roots=['0','1','1/2','9/16','9/8'],initial_values_checked=5))
    return reports

def rdm_checks():
    count = 0
    for n in (4,8,16):
        for b,S in enumerate(prefixes(n),1):
            p,r = spread_rdm(n,2*b)
            ids = {pair:i for i,pair in enumerate(p)}
            for c in range(1,n):
                for u,v in combinations(range(1,n),2):
                    assert Q(rnum(c,u,v,S),n*n) == r.get((ids[0,c],ids[u,v]),0)
                    count += 1
    return count

def recurrence_crosschecks():
    cases=[]
    for q,k in ((4,2),(8,4)):
        model=Recurrence(q,k)
        solutions={pair:model.solve(pair)[0] for pair in PAIRS}
        for n in (q,2*q,4*q):
            t=(n//q).bit_length()-1
            for pair in PAIRS:
                val=exact_all(n,pair)[0][k//2-1]
                expected=evaluate(solutions[pair],t)/n**5
                assert val == expected,(q,k,n,pair,val,expected)
                cases.append(dict(n=n,k=k,pair=pair,V=str(val)))
    return cases

def table_checks():
    summary=[]
    for n in (16,32,64,128):
        for pair in ((0,1),(1,3)):
            path=BASE/'results'/('finite-n%d-%d%d.json'%(n,*pair))
            data=json.loads(path.read_text())
            assert [r['k'] for r in data['rows']] == list(range(2,n//2+1,2))
            for row in data['rows']:
                v,h,ratio=map(Q,(row['V'],row['H'],row['ratio']))
                assert h==haar(n,row['k']) and v/h==ratio
                assert float(ratio)==row['decimal']
            endpoint_row=data['rows'][-1]
            r=n.bit_length()-3
            assert Q(endpoint_row['V'])*n**4==closed(r,pair)
            lo=min(data['rows'],key=lambda x:Q(x['ratio']))
            hi=max(data['rows'],key=lambda x:Q(x['ratio']))
            summary.append(dict(n=n,pair=pair,cases=len(data['rows']),
                                minimum=dict(k=lo['k'],ratio=lo['ratio'],decimal=lo['decimal']),
                                maximum=dict(k=hi['k'],ratio=hi['ratio'],decimal=hi['decimal'])))
    return summary

if __name__=='__main__':
    half=half_certificate();print('half-filling all-depth certificate: passed',flush=True)
    rdm=rdm_checks();print('full Walsh RDM entry comparisons:',rdm,flush=True)
    cross=recurrence_crosschecks();print('Fourier/recurrence cross-checks:',len(cross),flush=True)
    summary=table_checks()
    report=dict(status='passed',half_filling=half,rdm_entries=rdm,recurrence_crosschecks=cross,
                finite_table_summary=summary)
    (BASE/'results'/'round1-verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print('all round 1 exact checks passed',flush=True)
