"""Exact pair-tree moment recursion for the literal k=2 butterfly; standard library only."""
from fractions import Fraction as Q
from collections import defaultdict
from functools import lru_cache
from itertools import product
from math import comb, factorial
# Exponents: X[0:4],Y[4:8],conjX[8:12],conjY[12:16], a,b,conja,conjb.
N=20
ZERO=(0,)*N
ROWS=((0,1,2,3,8,9,10,11,16,18),(4,5,6,7,12,13,14,15,17,19))
KET=(0,1,2,3,4,5,6,7,16,17)
BRA=(8,9,10,11,12,13,14,15,18,19)
def mono(*idx):
    v=[0]*N
    for i in idx:v[i]+=1
    return tuple(v)
def plus(a,b):return tuple(x+y for x,y in zip(a,b))
def conj(e):return e[8:16]+e[:8]+e[18:20]+e[16:18]
def mul(a,b):
    c=defaultdict(Q)
    for e,x in a.items():
        for f,y in b.items():c[plus(e,f)]+=x*y
    return {e:x for e,x in c.items() if x}
def conjugate(a):return {conj(e):x for e,x in a.items()}
F={mono(0,5):Q(1),mono(1,4):Q(-1),mono(2,7):Q(1),mono(3,6):Q(-1)}
D={mono(16,5):Q(1),mono(1,17):Q(-1)}
FD=mul(conjugate(F),D)
G=defaultdict(Q,FD)
for e,c in conjugate(FD).items():G[e]-=c
# (i/2)^2 (F*D-FD*)^2 / m^4
TARGET={e:-c/4 for e,c in mul(G,G).items() if c}

def valid(e):
    for r in range(2):
        if sum(e[4*r:4*r+4])+e[16+r] !=sum(e[8+4*r:12+4*r])+e[18+r]:return False
    for j in range(4):
        k=e[j]+e[4+j];b=e[8+j]+e[12+j]
        if j==0:k+=e[16]+e[17];b+=e[18]+e[19]
        if k!=b:return False
    return True
@lru_cache(None)
def angular(p,q):
    if p%2 or q%2:return Q(0)
    a=p//2;b=q//2
    return Q(factorial(2*a)*factorial(2*b),4**(a+b)*factorial(a)*factorial(b)*factorial(a+b))
@lru_cache(None)
def splits(e):
    # All tags stay in branch A; B has none.
    active=[i for i in range(16) if e[i]]
    result=[]
    for vals in product(*(range(e[i]+1) for i in active)):
        a=list(e);b=[0]*N;c=Q(1)
        for i,v in zip(active,vals):
            a[i]=v;b[i]=e[i]-v;c*=comb(e[i],v)
        a=tuple(a);b=tuple(b)
        if not valid(a) or not valid(b):continue
        for row in ROWS:
            c*=angular(sum(a[i] for i in row),sum(b[i] for i in row))
        if c:result.append((a,b,c))
    return tuple(result)
@lru_cache(None)
def path4(out,inp):
    cur=inp;sgn=1;ang=[0]*8;phase=[0]*8
    for l in range(2):
        stride=1<<l
        phase[4*l+cur]+=1
        base=cur&~stride
        bases=[i for i in range(4) if not i&stride]
        gate=2*l+bases.index(base)
        changed=bool((cur^out)&stride)
        ang[2*gate+int(changed)]+=1
        if changed:
            if cur&stride:sgn=-sgn
            cur^=stride
    return sgn,tuple(ang),tuple(phase)
@lru_cache(None)
def base(e,i,j):
    ang=[0]*8;phase=[0]*8;sgn=1
    for v,power in enumerate(e):
        if not power:continue
        if v<16:
            column=v%4;row=i if (v//4)%2==0 else j;bar=v>=8
        else:
            column=0;row=i if v%2==0 else j;bar=v>=18
        s,a,p=path4(row,column);sgn*=s**power
        for t in range(8):ang[t]+=power*a[t];phase[t]+=(-1 if bar else 1)*power*p[t]
    if any(phase):return Q(0)
    out=Q(sgn)
    for t in range(0,8,2):out*=angular(ang[t],ang[t+1])
    return out

def closure():
    seen={ZERO};todo=[e for e in TARGET if valid(e)];seen.update(todo)
    while todo:
        e=todo.pop()
        for a,b,c in splits(e):
            for v in (a,b):
                if v not in seen:seen.add(v);todo.append(v)
    return sorted(seen,key=lambda e:(sum(e),sum(e[16:]),e))

def evolve(keys,i,j,steps):
    v={e:base(e,i,j) for e in keys}
    for t in range(steps+1):
        value=sum(c*v.get(e,0) for e,c in TARGET.items())/2**(4*t)
        n=4*2**t;haar=Q(4*(5*n-12),n**4*(n*n-1))
        yield t,value,value/haar,v
        v={e:sum(c*v[a]*v[b] for a,b,c in splits(e)) for e in keys}
if __name__=='__main__':
    keys=closure();print('keys',len(keys),'transitions',sum(len(splits(e)) for e in keys),flush=True)
    for pair in [(0,1),(0,2),(0,3)]:
        for t,var,ratio,v in evolve(keys,*pair,12):
            print(pair,t,str(var),float(ratio),flush=True)
