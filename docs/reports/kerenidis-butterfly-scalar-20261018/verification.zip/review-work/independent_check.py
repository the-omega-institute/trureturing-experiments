"""Referee reimplementation: Fock contraction, backwards paths, Fourier square.

No research implementation is imported.  Fractions are exact; finite recomputation
does not by itself prove the all-layer claims.
"""
from fractions import Fraction as F
from itertools import combinations, product
from math import factorial
from collections import defaultdict
import json
import sympy as sp


def fock_rdm(n, k):
    pp = list(combinations(range(n), 2))
    contractions = []
    for choice in product((0, 1), repeat=k//2):
        state = sum((3 if z == 0 else 12) << (4*a) for a,z in enumerate(choice))
        image = {}
        for p,(a,b) in enumerate(pp):
            if not ((state >> a)&1 and (state >> b)&1): continue
            # a_b a_a, acting from the right.
            one = state ^ (1 << a)
            s = (-1)**((state & ((1 << a)-1)).bit_count() +
                       (one & ((1 << b)-1)).bit_count())
            image[p] = (one ^ (1 << b), s)
        contractions.append(image)
    rr = sp.zeros(len(pp))
    for one in contractions:
        for two in contractions:
            for p,(rp,sgp) in one.items():
                for q,(rq,sgq) in two.items():
                    if rp == rq: rr[p,q] += sp.Rational(sgp*sgq, 2**(k//2))
    return pp,rr


def spread(n, k):
    pp,rr=fock_rdm(n,k)
    def walsh(a,b): return (-1)**((a&b).bit_count())
    hh=sp.Matrix([[walsh(a,c)*walsh(b,d)-walsh(a,d)*walsh(b,c)
                   for c,d in pp] for a,b in pp])
    return pp,hh*rr*hh.T/n**2


def exact_monomial_path(n, row, col):
    # Recover the incoming mode backwards, independently of forward path code.
    cur = row; sig=[]; trig=[]; sign=1
    for ell in reversed(range(n.bit_length()-1)):
        bit=1<<ell
        incoming = (cur & ~bit) | (col & bit)
        lower = incoming & ~bit
        flip = incoming != cur
        sig.append((ell,incoming))
        trig.append((ell,lower,int(flip)))
        if flip and (incoming&bit): sign *= -1
        cur=incoming
    assert cur == col
    return sign,sig,trig


def angular(c,s):
    if c%2 or s%2: return F(0)
    p,q=c//2,s//2
    return F(factorial(2*p)*factorial(2*q),
             4**(p+q)*factorial(p)*factorial(q)*factorial(p+q))


def direct_scalar(n,k,pair, pp=None, rr=None):
    if rr is None: pp,rr=spread(n,k)
    paths={(row,col):exact_monomial_path(n,out,col)
           for row,out in enumerate(pair) for col in range(n)}
    groups=defaultdict(lambda:defaultdict(F))
    for p,(a,b) in enumerate(pp):
        for q,(u,v) in enumerate(pp):
            derivative=int(a==0)-int(u==0)
            if not derivative or not rr[p,q]: continue
            for swap1,swap2 in product((0,1),repeat=2):
                ket=(b,a) if swap1 else (a,b)
                bra=(v,u) if swap2 else (u,v)
                coeff=F(rr[p,q])*derivative*(-1)**(swap1+swap2)
                frequency=defaultdict(int);angles=defaultdict(int)
                for pm,cols in ((1,ket),(-1,bra)):
                    for row,col in enumerate(cols):
                        sg,ph,tr=paths[row,col];coeff*=sg
                        for item in ph:frequency[item]+=pm
                        for item in tr:angles[item]+=1
                ff=tuple(sorted((key,power) for key,power in frequency.items() if power))
                aa=tuple(sorted(angles.items()))
                groups[ff][aa]+=coeff
    answer=F(0);count=0
    for freq,monomials in groups.items():
        opposite=tuple((key,-power) for key,power in freq)
        if opposite not in groups: continue
        for anglea,ca in monomials.items():
            if not ca: continue
            for angleb,cb in groups[opposite].items():
                if not cb: continue
                degrees=defaultdict(lambda:[0,0])
                for (ell,gate,kind),power in anglea+angleb:
                    degrees[ell,gate][kind]+=power
                value=-ca*cb
                for c,s in degrees.values(): value*=angular(c,s)
                answer+=value;count+=1
    return answer,dict(phase_groups=len(groups),products=count)


def benchmark(n,k):
    return F(2*k*((k*k-k+3)*(n-2*k)+7*k-6),n**4*(n*n-1))


def closed_half(r, family):
    return (F(273,64)*F(9,8)**r-F(7,2)+
            (F(535,64) if family=='A' else F(161,64))*F(9,16)**r-
            (F(57,8) if family=='A' else F(105,32))*F(1,2)**r)


def closed_four(s,family):
    if family=='A': coeff=[120,-F(891,8),F(533,64),F(179,2),-F(911,8),F(8567,128),-40]
    else: coeff=[120,-F(891,8),F(533,64),-F(287,4),F(125,2),F(5281,128),-F(323,8)]
    bases=[1,F(3,4),F(9,16),F(1,2),F(3,8),F(9,32),F(1,4)]
    return sum(c*b**s for c,b in zip(coeff,bases))


def normalization_check(n,k,pp,rr):
    delta=sp.diag(*[int(a==0) for a,b in pp])
    bb=delta*rr-rr*delta
    norm=sum(x*x for x in bb)
    def entry(a,b,c,d):
        if a==b or c==d:return 0
        sign=(-1 if a>b else 1)*(-1 if c>d else 1)
        return sign*bb[pp.index(tuple(sorted((a,b)))),pp.index(tuple(sorted((c,d))))]
    gamma=sp.Matrix(n,n,lambda a,c:sum(entry(a,d,c,d) for d in range(n)))
    gamma_norm=sum(x*x for x in gamma)
    expect=F(k*((k+2)*n-2*k*k+3*k-6),2*n*n)
    expect_gamma=F(k*(k-1)**2*(n-2*k),n*n)
    assert norm == expect, (n,k,norm,expect)
    assert gamma_norm == expect_gamma, (n,k,gamma_norm,expect_gamma)
    assert F(4*norm+2*gamma_norm,n*n*(n*n-1)) == benchmark(n,k)
    return dict(B_norm=str(norm),Gamma_norm=str(gamma_norm),H=str(benchmark(n,k)))


def main():
    out={"normalizations":[],"direct":[]}
    retaining={(0,1),(0,3),(1,2),(2,3)}
    for n in (4,8,16):
        for k in range(2,n//2+1,2):
            pp,rr=spread(n,k)
            norms=normalization_check(n,k,pp,rr)
            out['normalizations'].append(dict(n=n,k=k,**norms))
            if (n,k) not in ((4,2),(8,2),(8,4),(16,4),(16,8)):continue
            for pair in combinations(range(4),2):
                value,stats=direct_scalar(n,k,pair,pp,rr)
                family='A' if pair in retaining else 'C'
                if k==n//2:
                    r=(n//4).bit_length()-1
                    assert value*n**4 == closed_half(r,family),(n,k,pair,value)
                if k==4:
                    s=(n//8).bit_length()-1
                    assert value*n**5 == closed_four(s,family),(n,k,pair,value)
                record=dict(n=n,k=k,pair=pair,V=str(value),ratio=str(value/benchmark(n,k)),**stats)
                out['direct'].append(record);print(record,flush=True)
    with open('review-work/independent-results.json','w') as f:json.dump(out,f,indent=2)
    print('All independent Fock, normalization and direct Fourier checks passed.',flush=True)


if __name__=='__main__':main()
