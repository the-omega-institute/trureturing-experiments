"""Independent reconstruction of all 16 half-filling mask transfers.

Only independent_check (the referee's own backwards path integrator) is imported.
"""
from independent_check import F, angular, exact_monomial_path, closed_half
from itertools import combinations, product
from collections import defaultdict
import sympy as sp
import json

states=[set(range(4)),{0,1},{0,2},{0,3},{0}]
reps=[(0,0),(0,1),(1,0),(1,1),(1,2)]

def partition(kernel):
    return {tuple(sorted(x^v for v in kernel)) for x in range(4)}

def assignment(mask):
    out=[]
    for a,b in ((0,1),(2,3),(0,1),(2,3)):
        if mask&1:a,b=b,a
        out.append((a,b));mask>>=1
    return out

def transfer(mask):
    factors=assignment(mask)
    mat=sp.zeros(5)
    for si,old in enumerate(states):
        for hbit,gbit in product(range(2),repeat=2):
            bits=[0,hbit,gbit,hbit^gbit]
            new={x for x in old if not bits[x]}
            sj=states.index(new)
            w=F(1)
            for row in (0,1):
                ket=[factors[t][row] for t in (0,1)]
                bra=[factors[t][row] for t in (2,3)]
                if any(sum(a in cl for a in ket)!=sum(a in cl for a in bra)
                       for cl in partition(new)):
                    w=F(0);break
                for cl in partition(old):
                    columns=[a for a in ket+bra if a in cl]
                    sine=sum(bits[a] for a in columns)
                    w*=angular(len(columns)-sine,sine)
            mat[si,sj]+=w
    return mat

def coeff(c,u,v):
    def char(a,s):return (-1)**((a&s).bit_count())
    def det(a,b,s,t):return char(a,s)*char(b,t)-char(a,t)*char(b,s)
    x=F((det(0,c,0,1)+det(0,c,2,3))*(det(u,v,0,1)+det(u,v,2,3)),2)
    x-=sum(F(det(0,c,s,t)*det(u,v,s,t),4) for s,t in combinations(range(4),2))
    return x

def low_moment(pair,columns,mask):
    ff=defaultdict(int);tt=defaultdict(lambda:[0,0]);sgn=(-1)**mask.bit_count()
    for t,rows in enumerate(assignment(mask)):
        for row,label in enumerate(rows):
            ss,phase,angles=exact_monomial_path(16,pair[row],columns[label])
            # high-layer signs occur twice per input column and cancel in total.
            for ell,mode in phase:
                if ell<2:ff[ell,mode]+=1 if t<2 else -1
            for ell,gate,kind in angles:
                if ell<2:
                    tt[ell,gate][kind]+=1
                    if kind and (columns[label]&(1<<ell)):sgn*=-1
    if any(ff.values()):return F(0)
    value=F(sgn)
    for c,s in tt.values():value*=angular(c,s)
    return value

def endpoint(pair,mask):
    vec=[]
    for state,(h,g) in zip(states,reps):
        val=F(0)
        for c,u in product(range(4),repeat=2):
            v=c^u;weight=coeff(c,u,v)
            if not weight:continue
            full=(0,4*h+c,4*g+u,4*(h^g)+v)
            if full[2]==0 or full[3]==0:continue
            val+=weight*weight*low_moment(pair,full,mask)
        vec.append(val)
    return sp.Matrix(vec)

def main():
    mats=[transfer(m) for m in range(16)]
    x=sp.symbols('x')
    p=x*(x-1)*(x-sp.Rational(1,2))*(x-sp.Rational(9,16))*(x-sp.Rational(9,8))
    for m,t in enumerate(mats):
        poly=sp.Poly(p,x)
        assert sum((c*(4*t)**power[0] for power,c in poly.terms()),sp.zeros(5))==sp.zeros(5),m
    grouped=[
        sp.Matrix([[9,1,9,1,0],[0,8,0,0,8],[0,0,18,0,2],[0,0,0,8,8],[0,0,0,0,16]])/16,
        sp.Matrix([[9,1,0,0,0],[0,8,0,0,0],[0,0,0,0,0],[0,0,0,0,0],[0,0,0,0,0]])/16,
        sp.Matrix([[9,1,0,1,0],[0,8,0,0,0],[0,0,0,0,0],[0,0,0,8,0],[0,0,0,0,0]])/16]
    grouped_terms={
        'A':[[F(9,8),F(53,8),F(49,64),F(49,16),F(7,2)],
             [F(3,4),F(15,4),0,0,0],[F(1,8),F(5,8),0,F(1,16),0]],
        'C':[[F(3,16),F(77,32),F(49,64),F(361,64),F(7,2)],
             [-F(3,8),F(19,16),0,0,0],[F(3,16),F(13,32),0,F(41,64),0]]}
    for family,vectors in grouped_terms.items():
        for r in range(6):
            assert sum(((m**r)*sp.Matrix(v))[0] for m,v in zip(grouped,vectors))==closed_half(r,family)
    results=[]
    for pair in combinations(range(4),2):
        terminals=[endpoint(pair,m) for m in range(16)]
        family='C' if pair in ((0,2),(1,3)) else 'A'
        for r in range(6):
            actual=sum(((4*t)**r*ll)[0] for t,ll in zip(mats,terminals))
            assert actual==closed_half(r,family),(pair,r,actual)
        # Since polynomial annihilation is exact, 5 initial equalities prove all r.
        results.append(dict(pair=pair,formula=family,initial_values=6,
                            endpoints=[[str(v) for v in ll] for ll in terminals]))
        print('All-layer transfer reconstructed and verified:',pair,family,flush=True)
        path=f'verification/results/half-filling-{pair[0]}{pair[1]}.json'
        try:
            with open(path) as f:cert=json.load(f)
        except FileNotFoundError:continue
        assert all(t==sp.Matrix([[sp.Rational(v) for v in row] for row in tt])
                   for t,tt in zip(mats,cert['matrices']))
        assert all(list(ll)==[sp.Rational(v) for v in vv] for ll,vv in zip(terminals,cert['endpoints']))
    with open('review-work/independent-transfer.json','w') as f:
        json.dump(dict(status='passed',annihilator=str(p),displayed_grouped_matrices_and_terminals='passed',cases=results),f,indent=2)

if __name__=='__main__':main()
