"""Independent finite checks; n=16 full direct scalar, larger-table consistency."""
from independent_check import spread,direct_scalar,benchmark,closed_half,F
from pathlib import Path
import json

out=[]
for n in (16,32,64,128):
    for pair in ((0,1),(1,3)):
        file=Path(f'verification/results/finite-n{n}-{pair[0]}{pair[1]}.json')
        data=json.loads(file.read_text());rows=data['rows']
        assert [r['k'] for r in rows]==list(range(2,n//2+1,2))
        for row in rows:
            v,h=F(row['V']),F(row['H']);k=row['k']
            assert h==benchmark(n,k)
            assert F(row['ratio'])==v/h
            assert abs(row['decimal']-float(v/h))<1e-14
            if k==n//2:
                family='A' if pair==(0,1) else 'C'
                assert v*n**4==closed_half((n//4).bit_length()-1,family)
            if n==16:
                pp,rr=spread(n,k)
                recomputed,stats=direct_scalar(n,k,pair,pp,rr)
                assert recomputed==v,(n,k,pair)
        lower=min(rows,key=lambda r:F(r['ratio']));upper=max(rows,key=lambda r:F(r['ratio']))
        record=dict(n=n,pair=pair,entries=len(rows),minimum=dict(k=lower['k'],value=lower['decimal']),
                    maximum=dict(k=upper['k'],value=upper['decimal']),
                    direct_recomputed='all rows' if n==16 else 'half-filling endpoint via independent transfer')
        out.append(record);print(record,flush=True)
Path('review-work/table-checks.json').write_text(json.dumps(out,indent=2)+'\n')
