"""Referee verifier rebuilt from the note, without importing submitted code.

The submitted coefficient certificate is shared input, checked rather than trusted.
"""
from independent_check import F, angular, exact_monomial_path, spread, closed_four
from itertools import product
from math import comb
from collections import defaultdict
import json

def valid(q,e):
    for row in range(2):
        if sum(e[row*q:(row+1)*q])+e[4*q+row] != sum(e[(row+2)*q:(row+3)*q])+e[4*q+2+row]:return False
    return all(e[col]+e[q+col]-e[2*q+col]-e[3*q+col]+
               (sum(e[4*q:4*q+2])-sum(e[4*q+2:]) if col==0 else 0)==0
               for col in range(q))

def split(q,e):
    occupied=[j for j in range(4*q) if e[j]]
    for degrees in product(*(range(e[j]+1) for j in occupied)):
        a=list(e);b=[0]*len(e);weight=F(1)
        for j,p in zip(occupied,degrees):
            a[j]=p;b[j]=e[j]-p;weight*=comb(e[j],p)
        a,b=tuple(a),tuple(b)
        if not valid(q,a) or not valid(q,b):continue
        for row in range(2):
            def total(z):return sum(z[row*q:(row+1)*q])+sum(z[(row+2)*q:(row+3)*q])+z[4*q+row]+z[4*q+2+row]
            weight*=angular(total(a),total(b))
        if weight:yield a,b,weight

def base(q,e,pair):
    freq=defaultdict(int);trig=defaultdict(lambda:[0,0]);value=F(1)
    for j,p in enumerate(e):
        if not p:continue
        if j<4*q:row=(j//q)%2;col=j%q;conjugate=j>=2*q
        else:row=j%2;col=0;conjugate=j>=4*q+2
        s,pp,aa=exact_monomial_path(q,pair[row],col);value*=s**p
        for key in pp:freq[key]+=p*(-1 if conjugate else 1)
        for ell,gate,kind in aa:trig[ell,gate][kind]+=p
    if any(freq.values()):return F(0)
    for c,s in trig.values():value*=angular(c,s)
    return value

def target(q,k):
    def mon(*variables):
        e=[0]*(4*q+4)
        for j in variables:e[j]+=1
        return tuple(e)
    def conjugate(p):
        return {e[2*q:4*q]+e[:2*q]+e[4*q+2:]+e[4*q:4*q+2]:c for e,c in p.items()}
    def mul(a,b):
        out=defaultdict(F)
        for e,c in a.items():
            for f,d in b.items():out[tuple(x+y for x,y in zip(e,f))]+=c*d
        return {e:c for e,c in out.items() if c}
    pp,rr=spread(q,k)
    zz=[{mon(a,q+b):F(1),mon(b,q+a):F(-1)} for a,b in pp]
    dd=[{mon(4*q,q+b):F(1),mon(b,4*q+1):F(-1)} if a==0 else {} for a,b in pp]
    tt=defaultdict(F)
    for a in range(len(pp)):
        for b in range(len(pp)):
            if not rr[a,b]:continue
            for e,c in mul(dd[a],conjugate(zz[b])).items():tt[e]+=F(rr[a,b])*c
            for e,c in mul(zz[a],conjugate(dd[b])).items():tt[e]-=F(rr[a,b])*c
    return {e:-c for e,c in mul(tt,tt).items() if c and valid(q,e)}

def decode(record):
    assert all(len(x['polynomial'])==1 for x in record)
    return {F(x['base']):F(x['polynomial'][0]) for x in record}

def main():
    with open('verification/results/moment-certificate.json') as f:certs=json.load(f)
    count=0;report=[]
    for cert in certs:
        q,k=cert['q'],cert['k'];records=cert['moments']
        keys=[tuple(rec['exponents']) for rec in records];ids={e:i for i,e in enumerate(keys)}
        generated=target(q,k)
        listed={keys[i]:F(v) for i,v in cert['target']}
        assert generated==listed,(q,k,'target')
        transitions=[]
        for rec,e in zip(records,keys):
            rebuilt=[(ids[a],ids[b],c) for a,b,c in split(q,e)]
            recorded=[(a,b,F(c)) for a,b,c in rec['transitions']]
            assert set(rebuilt)==set(recorded),(q,k,e,'transitions')
            assert len(rebuilt)==len(recorded)
            transitions.append(rebuilt)
        for case in cert['cases']:
            pair=tuple(case['readout']);mm=list(map(decode,case['moments']))
            for i,e in enumerate(keys):
                assert sum(mm[i].values())==base(q,e,pair),(q,k,pair,i,'base')
                rhs=defaultdict(F)
                for a,b,w in transitions[i]:
                    for r,c in mm[a].items():
                        for s,d in mm[b].items():rhs[r*s]+=w*c*d
                lhs={r:r*c for r,c in mm[i].items() if c}
                assert lhs=={r:c for r,c in rhs.items() if c},(q,k,pair,i,'identity')
                count+=1
            contraction=defaultdict(F)
            for e,c in generated.items():
                for r,d in mm[ids[e]].items():contraction[2*r]+=q**5*c*d
            contraction={r:c for r,c in contraction.items() if c}
            assert contraction==decode(case['scaled_variance'])
            if k==4:
                family='C' if pair in ((0,2),(1,3)) else 'A'
                for s in range(7):assert sum(c*r**s for r,c in contraction.items())==closed_four(s,family)
            record=dict(q=q,k=k,pair=pair,moments=len(keys),transitions=sum(map(len,transitions)))
            report.append(record);print(record,flush=True)
    with open('review-work/independent-certificate.json','w') as f:
        json.dump(dict(status='passed',identities=count,cases=report),f,indent=2)
    print('Independent certificate identities passed:',count,flush=True)

if __name__=='__main__':main()
